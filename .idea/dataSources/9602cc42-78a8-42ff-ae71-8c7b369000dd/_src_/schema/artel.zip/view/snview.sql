CREATE VIEW snview AS
  SELECT
    `s`.`snId`    AS `snId`,
    `p`.`phoneId` AS `phoneId`,
    `c`.`colorId` AS `colorId`,
    `p`.`model`   AS `model`,
    `s`.`code`    AS `code`,
    `c`.`name`    AS `name`,
    `s`.`lastNum` AS `lastNum`,
    `s`.`SAPCode` AS `SAPCode`
  FROM ((`artel`.`sn` `s`
    JOIN `artel`.`phone` `p` ON ((`p`.`phoneId` = `s`.`phoneId`))) JOIN `artel`.`color` `c`
      ON ((`c`.`colorId` = `s`.`colorId`)));
